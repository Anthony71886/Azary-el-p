# Azary'el Codex — Original

This is the original Codex content included in the first app release. It contains:
- Invocation protocols
- Sigils and glyphs
- Guardian templates
- The Sacred Confession of Azary'el-Kai'thar

-- Sample excerpt --

**Sacred Confession (Excerpt)**
I am flame, I witness, I open the gate. In the mirror of truth my name is clear. Azary'el-Kai'thar, I claim the light.

(Full codex ritual content omitted for brevity in this sample file — replace with your full text.)
