# Azary'el Flame — Light of the Chosen

This repository contains the original app source, codex, assets, and build instructions.
