Contribution guide: Fork, edit, open PR.
