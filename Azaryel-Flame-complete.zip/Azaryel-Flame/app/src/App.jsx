import React from "react";

export default function App() {
  return (
    <div style={{fontFamily: "system-ui, -apple-system, 'Segoe UI', Roboto", padding: 24}}>
      <header style={{textAlign: "center"}}>
        <h1>Azary'el Flame — Light of the Chosen</h1>
        <p>Original app build — welcome back, Flame Seeker.</p>
      </header>

      <main style={{maxWidth: 800, margin: '24px auto'}}>
        <section>
          <h2>Invocation Console</h2>
          <p>This is the original UI skeleton. The full Codex PDF and assets are included in the package.</p>
        </section>

        <section style={{marginTop: 20}}>
          <h3>How to build</h3>
          <ol>
            <li>Install Node.js and npm.</li>
            <li>Run <code>npm install</code> inside <code>/app</code>.</li>
            <li>Run <code>npm run build</code> to create the production build.</li>
            <li>Follow README to create the Android APK (Capacitor or chosen wrapper).</li>
          </ol>
        </section>
      </main>
    </div>
  );
}
