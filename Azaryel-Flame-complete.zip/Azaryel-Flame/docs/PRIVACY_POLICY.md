# Privacy Policy — Azary'el Flame: Light of the Chosen

_Last updated: September 15, 2025_

**Summary:** This app collects no personal data by default. If you create an account or enable cloud backups, minimal data (email, username) may be stored to provide your Codex sync and restore features. You may request deletion at any time using the Delete Data URL or by emailing the developer.

**Data collected (if enabled):**
- Email (for account / restore)
- Optional profile display name
- Crash logs (anonymous) — only if you enable crash reporting

**Use of data:**
- Provide account and restore functionality
- Improve app stability
- Do not sell or share user personal data

**Contact / Delete requests:**
To request deletion of all personal data, follow the Delete Data instructions in `DELETE_DATA.md` or visit the hosted Delete Data URL (add your repo GitHub Pages link + `/docs/DELETE_DATA.md`).

