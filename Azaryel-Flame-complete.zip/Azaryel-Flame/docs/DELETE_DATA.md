# Delete Data Instructions — Azary'el Flame

If you want to delete your personal data associated with this app, use one of the following options:

1. **In-app delete:** If you have an account, open Settings → Data & Privacy → Delete My Data.
2. **Email request:** Send an email to the developer (use your GitHub account email) with subject 'Delete My Azaryel Data' and include your account username.
3. **Hosted delete URL:** If you host this repo on GitHub Pages you can create a simple API endpoint or a GitHub Actions workflow to handle authenticated delete requests. Example placeholder URL: `https://your-domain.example.com/delete-data`

If you need help implementing a server-side delete endpoint, the README contains step-by-step guidance.

